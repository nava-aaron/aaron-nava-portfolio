# POSITIONING.md

## Core Brand Voice & Tone

**Conversational with contractions.** Vary sentence length dramatically—short punchy ones, then longer flowing sentences. Natural pauses... and tangents. Simple language like talking to a friend. Relatable metaphors over jargon. Show understanding of reader's challenges. Make it slightly "messy" with asides, second thoughts. Connect emotionally first, provide value second.

**CEO-level clarity.** Plain metaphors, plain analogies. No music industry references (bass player, etc.). Speak like an executive speaks to other executives.

**Confidence without ego.** Strong, direct, but not arrogant. The facts speak. You don't need to oversell.

---

## The Full Positioning Statement

### Hero/Main Positioning:

**"I close major business AND I build the systems to deliver on it. I'm equally strong at the pitch and the partnership. I don't hand off deals to someone else—I own the full arc."**

This is the core. Everything else supports it.

### Extended Positioning (Full Paragraph):

I'm brought in to close major opportunities ($3M-$20M, formal RFP processes). Once I'm in the room, I have a 90% conversion rate from first call to RFP invitation, and an 85% win rate on the deal itself. But closing is only half the story. I build the operational systems that let complex organizations deliver on those promises. I develop teams that can run those systems independently. I manage client relationships through it all—because I stay involved, I know what's real and what's BS.

I've done this at every scale: started with 6 people (Circus), grew to 100 in 18 months while staying sane. Scaled a global capability from $20M to $115M while integrating 33 acquisitions and maintaining 15-20% organic growth for four consecutive years. Built a 1,200-person operation at its peak.

I don't just build. I close. I deliver. I develop people. I stay calm under pressure. And I don't need credit—people notice the impact once I leave.

---

## The Pattern (Why This Works)

**The Full Arc:**
1. **Close:** 90% intro-to-pitch conversion, 85% win rate on major deals
2. **Build:** Develop operating systems that scale without breaking culture
3. **Deliver:** Stay involved to manage client relationships and ensure execution
4. **Develop:** Create teams that can run things independently after you leave
5. **Stabilize:** Known for bringing calm to chaos (M&A, restructures, high-pressure moments)

This is rare. Most people who close deals hand them off. Most people who build systems never talk to clients. You do both.

---

## Why This Positioning Works for Each Buyer

### Platform Companies (Amazon, Google, LinkedIn, Spotify, Adobe)

**Their Need:** Someone who can manage complex creator/partner relationships at scale, build operational infrastructure, develop team expertise in-house.

**Your Angle:** "I've been on the vendor side for 15 years. I know what enterprise customers (agencies/brands) struggle with. I can build the operational backbone that turns platform relationships into scaled, predictable revenue. I bring in-house operational expertise that most platform teams lack."

**The Proof:** Monks—1,200 people coordinating distribution across multiple platforms. You know how to operationalize chaos.

---

### Publicis/Razorfish & Major Holding Companies

**Their Need:** Someone who can manage high-volume pitch activity, close major business, AND manage the "pirate ship to navy ship" integration challenge.

**Your Angle:** "I've scaled organizations at every phase. I know how to grow fast without losing the culture that made you special. I bring both growth discipline AND operational rigor. I close major business AND I make sure it gets delivered."

**The Proof:** Circus (6→100) + Monks ($20M→$115M with 33 integrations). You've navigated the exact scaling challenges they're facing.

---

### Inflection-Point Companies (Series B-D, Scaling Rapidly)

**Their Need:** Someone who can architect the operating system for the next phase of growth.

**Your Angle:** "I've built this blueprint before. Here's what breaks when you scale. Here's how I prevent it. I'm the COO/Chief Builder who turns founder-led chaos into professional operations without killing the culture."

**The Proof:** Circus case study. 6 people → 100, installed governance and P&L discipline, prepared for acquisition in 18 months.

---

### Selective Startups (Strong Revenue, Real Funding)

**Their Need:** Fractional operational leader who can install the systems the founder can't.

**Your Angle:** "I've built departments from 6 people to global operations. I specialize in the transition—when founder-led operations hit the ceiling and you need to scale without the founder becoming a bottleneck."

**The Proof:** Your entire arc shows this. Conill → Joe → Circus → Monks.

---

## Key Differentiators (What Makes You Different)

1. **Full-Arc Operator:** Not siloed in growth or operations. You own both.
2. **The Closer:** 90% intro-to-pitch conversion. You don't waste time.
3. **The Builder:** 4 major department builds from zero. You know how to scale.
4. **The Integrator:** 33 agencies unified into one operating model. You can translate between silos.
5. **The Stabilizer:** Known for bringing calm to chaos. People trust you under pressure.
6. **The Developer:** You don't hoard knowledge. You develop people who carry things forward.
7. **No Ego:** You're quietly relentless. People notice the impact once you're gone.

---

## What NOT to Say

- Don't position as a "growth specialist" (too narrow, suggests you only hunt)
- Don't position as an "operational expert" (too narrow, suggests you only build)
- Don't use metaphors (bass player, pirate ship, navy ship internally explain the idea, but not on the website for the general audience)
- Don't over-emphasize M&A integration (works for Publicis, not for Amazon)
- Don't make it about "transitioning to depth" (no one cares about your career arc, they care about what you'll do for them)
- Don't use jargon (no "agentic workflows," no "commercial architecture"—say what you actually do)

---

## Website Sections That Use This Positioning

### Hero Section
Lead with: "I close major business AND I build the systems to deliver on it."

### About Section
Full positioning paragraph (see Extended Positioning above).

### The Pattern Section
Show the 5-step arc (Close → Build → Deliver → Develop → Stabilize).

### Case Studies
Monks: Full arc in action at global scale
Circus: Growth arc, founder's right hand

### Testimonials
Strategic selections by competency:
- "Closes major deals under pressure"
- "Builds systems that scale"
- "Develops people"
- "Stays calm in chaos"
- "Delivers with consistency"

### Call-to-Action
"If you're closing major business, building complex operations, or navigating a scaling challenge—let's talk."

---

## Brand Anchors (Always Include)

These numbers/facts appear everywhere:
- 90% intro-to-pitch conversion
- 85% win rate on major deals ($3M-$20M)
- $115M+ global P&L
- 15-20% YoY organic growth (4 consecutive years)
- 33 agencies integrated
- 1,200 people at peak
- 4 major builds from zero
- 15+ years in the industry

Not all in every section, but scattered throughout to build credibility.

---

## The Tone in Practice

**Not this:** "I am a visionary leader who has demonstrated excellence across multiple domains."

**But this:** "I close major deals. I build the systems to deliver on them. I develop the people who run them after I leave. And I do it without drama or ego."

**Not this:** "My operational expertise enables scalable growth."

**But this:** "I take fragmented processes and turn them into repeatable machines."

**Not this:** "I specialize in post-merger integration optimization."

**But this:** "I've integrated 33 agencies. I know what works. I know where it breaks. I know how to fix it."

---

## Final Positioning Check

Does this feel true? Yes.
Does this feel impressive? Yes.
Does this work for all four buyer types? Yes (with slight angle shifts, but core is same).
Does this avoid sounding like everyone else? Yes.
Does this make hiring managers go "holy shit, this guy is the real deal"? Yes.

✅ **Positioning locked.**
